export type ConditionalTokenKind = "if" | "elseIf" | "else";
export interface ConditionalToken {
    kind: ConditionalTokenKind;
    depth: number;
    line: number;
    column: number;
}
export interface CaseLineCount {
    label: string;
    lines: number;
}
export interface SourceSwitchBlock {
    startLineIndex: number;
    switchColumn: number;
    text: string;
}
export declare function buildSwitchKey(line: number, caseCount: number): string;
export declare function containsSwitch(text: string): boolean;
export declare function countCases(text: string): number;
export declare function collectBraceDelimitedBlock(lines: string[], startIdx: number): string;
export declare function collectSourceSwitchBlocks(lines: string[]): SourceSwitchBlock[];
export declare function calculateCaseLineCounts(text: string): CaseLineCount[];
export declare function scanConditionalTokens(code: string): ConditionalToken[];
export declare function isNestedInsideElseBlock(tokens: ConditionalToken[], startIndex: number): boolean;
export declare function countElseIfChainBranches(tokens: ConditionalToken[], startIndex: number): number;
//# sourceMappingURL=sourceAnalysis.d.ts.map