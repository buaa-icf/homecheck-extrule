import { ArkMethod } from "arkanalyzer";
import { BaseMetaData, BaseChecker, Rule, MatcherCallback, IssueReport } from "homecheck";
export declare class ForeachArgsCheck implements BaseChecker {
    readonly metaData: BaseMetaData;
    readonly FOREACH_CLASS: string;
    readonly CREATE_METHOD: string;
    rule: Rule;
    issues: IssueReport[];
    private readonly defaultOptions;
    private options;
    private optionsInitialized;
    private clsMatcher;
    private buildMatcher;
    private builderMatcher;
    beforeCheck(): void;
    private getOptions;
    registerMatchers(): MatcherCallback[];
    check: (targetMtd: ArkMethod) => void;
    private addIssueReport;
    private getLineAndColumn;
}
//# sourceMappingURL=ForEachArgsCheck.d.ts.map