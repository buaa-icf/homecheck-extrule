import { ArkMethod } from "arkanalyzer";
import { BaseMetaData, MatcherCallback } from "homecheck";
import { RuleOptionSchema } from "./config/parseRuleOptions";
import { ForeachArgsRuleOptions } from "./config/types";
import { BaseRuleChecker } from "./BaseRuleChecker";
export declare class ForEachArgsCheck extends BaseRuleChecker<ForeachArgsRuleOptions> {
    readonly metaData: BaseMetaData;
    readonly FOREACH_CLASS: string;
    readonly CREATE_METHOD: string;
    protected readonly optionSchema: RuleOptionSchema<ForeachArgsRuleOptions>;
    protected readonly defaultOptions: ForeachArgsRuleOptions;
    private clsMatcher;
    private buildMatcher;
    private builderMatcher;
    registerMatchers(): MatcherCallback[];
    check: (targetMtd: ArkMethod) => void;
    private addIssueReport;
    private getLineAndColumn;
}
//# sourceMappingURL=ForEachArgsCheck.d.ts.map