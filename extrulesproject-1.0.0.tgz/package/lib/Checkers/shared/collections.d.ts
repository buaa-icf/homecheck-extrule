export declare function appendToBucket<TKey, TValue>(buckets: Map<TKey, TValue[]>, key: TKey, value: TValue): TValue[];
export declare function groupBy<TKey, TValue>(items: Iterable<TValue>, keySelector: (item: TValue) => TKey): Map<TKey, TValue[]>;
export declare function flattenBuckets<TKey, TValue>(buckets: Map<TKey, TValue[]>): TValue[];
export declare function pairwiseCombinations<TItem>(items: TItem[]): Array<[TItem, TItem]>;
//# sourceMappingURL=collections.d.ts.map