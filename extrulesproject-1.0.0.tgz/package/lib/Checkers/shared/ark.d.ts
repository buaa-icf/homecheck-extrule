import { ArkMethod, Stmt } from "arkanalyzer";
export declare function getMethodEndLine(method: ArkMethod): number;
export declare function shouldSkipClass(className: string): boolean;
export declare function shouldSkipMethod(methodName: string): boolean;
export declare function isArkUiMethod(method: ArkMethod): boolean;
export declare function isLogStatement(stmt: Stmt): boolean;
//# sourceMappingURL=ark.d.ts.map