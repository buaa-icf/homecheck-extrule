export declare function getBaseName(filePath: string): string;
//# sourceMappingURL=path.d.ts.map