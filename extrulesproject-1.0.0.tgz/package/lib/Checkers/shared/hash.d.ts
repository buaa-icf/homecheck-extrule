export declare function djb2Hash(str: string): string;
//# sourceMappingURL=hash.d.ts.map