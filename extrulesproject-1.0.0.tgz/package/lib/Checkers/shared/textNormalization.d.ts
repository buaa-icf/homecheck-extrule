export declare function normalizeBasic(text: string): string;
export declare function normalizeIdentifiers(text: string, identifierMap: Map<string, string>, normalizeSingleChar?: boolean): string;
export declare function normalizeLiterals(text: string): string;
export declare function stripTypeAnnotations(text: string): string;
export declare function stripDecorators(text: string): string;
//# sourceMappingURL=textNormalization.d.ts.map