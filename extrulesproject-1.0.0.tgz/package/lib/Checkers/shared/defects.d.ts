import { IssueReport } from "homecheck";
import { PriorityResult } from "../priority/PriorityScorer";
export interface DefectsParams {
    line: number;
    startCol: number;
    endCol: number;
    description: string;
    severity: number;
    ruleId: string;
    filePath: string;
    ruleDocPath: string;
    methodName?: string;
    showIgnoreIcon?: boolean;
    disabled?: boolean;
    checked?: boolean;
    fixable?: boolean;
    priority?: PriorityResult;
}
export declare function createDefects(params: DefectsParams): IssueReport;
//# sourceMappingURL=defects.d.ts.map