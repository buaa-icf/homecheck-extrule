import { Rule } from "homecheck";
import { DefectsParams } from "./reporting";
import { djb2Hash, getMethodEndLine, isLogStatement, normalizeBasic, normalizeIdentifiers, normalizeLiterals, shouldSkipClass, shouldSkipMethod, stripDecorators, stripTypeAnnotations } from "./shared";
/**
 * @deprecated Use parseRuleOptions from ./config directly.
 */
export declare function getRuleOption<T extends Record<string, unknown>>(rule: Rule, defaults: T): T;
export declare function createDefects(params: DefectsParams): import("homecheck").IssueReport;
export { DefectsParams, djb2Hash, getMethodEndLine, isLogStatement, normalizeBasic, normalizeIdentifiers, normalizeLiterals, shouldSkipClass, shouldSkipMethod, stripDecorators, stripTypeAnnotations };
//# sourceMappingURL=utils.d.ts.map