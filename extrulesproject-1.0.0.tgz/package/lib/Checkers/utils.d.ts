import { IssueReport } from "homecheck";
import { djb2Hash, getMethodEndLine, isLogStatement, normalizeBasic, normalizeIdentifiers, normalizeLiterals, shouldSkipClass, shouldSkipMethod, stripDecorators, stripTypeAnnotations } from "./shared";
export interface DefectsParams {
    line: number;
    startCol: number;
    endCol: number;
    description: string;
    severity: number;
    ruleId: string;
    filePath: string;
    ruleDocPath: string;
    methodName?: string;
    showIgnoreIcon?: boolean;
    disabled?: boolean;
    checked?: boolean;
    fixable?: boolean;
}
export declare function createDefects(params: DefectsParams): IssueReport;
export { djb2Hash, getMethodEndLine, isLogStatement, normalizeBasic, normalizeIdentifiers, normalizeLiterals, shouldSkipClass, shouldSkipMethod, stripDecorators, stripTypeAnnotations };
//# sourceMappingURL=utils.d.ts.map