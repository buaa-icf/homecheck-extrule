import { ArkFile, ArkMethod, Stmt } from "arkanalyzer";
import { AdviceChecker, BaseMetaData, IssueReport, MatcherCallback, Rule } from "homecheck";
import { MethodCloneRuleOptions } from "./config/types";
import { ClonePair, MethodInfo } from "./method-clone";
/**
 * 方法级克隆检测基类。
 *
 * 职责：
 * 1. 收集方法并做基础过滤；
 * 2. 组织精确克隆与近似克隆检测流程；
 * 3. 统一构建 Issue 报告。
 */
export declare abstract class CodeCloneBaseCheck implements AdviceChecker {
    abstract readonly metaData: BaseMetaData;
    rule: Rule;
    issues: IssueReport[];
    arkFiles: ArkFile[];
    protected options: MethodCloneRuleOptions;
    private optionsResolved;
    protected methodsByHash: Map<string, MethodInfo[]>;
    protected collectedMethodKeys: Set<string>;
    protected reportedPairs: Set<string>;
    protected collectedPairs: ClonePair[];
    private fileMatcher;
    protected abstract getCloneType(): string;
    /**
     * 由子类实现具体规范化策略并返回哈希与规范化内容。
     */
    protected abstract computeHash(stmts: Stmt[]): {
        hash: string;
        normalizedContent: string;
    };
    /**
     * 默认描述模板；子类可按规则类型覆盖。
     */
    protected getDescription(method: MethodInfo, cloneWith: MethodInfo, _pair?: ClonePair): string;
    /**
     * 每轮检测开始时重置状态并解析配置。
     */
    beforeCheck(): void;
    check: () => void;
    /**
     * 注册 FILE 级匹配器，驱动方法收集。
     */
    registerMatchers(): MatcherCallback[];
    /**
     * 从 ArkFile 收集候选方法并按身份去重后入桶。
     */
    collectMethods: (arkFile: ArkFile) => void;
    /**
     * 收尾阶段：先做精确克隆，再按阈值可选做近似克隆，最后按配置决定是否聚合为克隆类。
     */
    afterCheck(): void;
    /**
     * 提取方法元信息与规范化结果；不满足条件时返回 null。
     */
    protected extractMethodInfo(method: ArkMethod, filePath: string, className: string): MethodInfo | null;
    /**
     * 文本基础规范化工具（供子类复用）。
     */
    protected normalizeBasic(text: string): string;
    /**
     * 默认哈希函数（DJB2）。
     */
    protected simpleHash(str: string): string;
    /**
     * 将方法按 hash 分桶，供后续配对。
     */
    protected addMethodToHash(methodInfo: MethodInfo): void;
    /**
     * 从 hash 桶中生成精确克隆对并上报。
     */
    protected findClonePairs(): void;
    /**
     * 单个克隆对上报入口，包含去重与聚合收集。
     */
    protected reportClonePair(pair: ClonePair): void;
    /**
     * 生成无序克隆对唯一键，避免双向重复。
     */
    protected getPairKey(pair: ClonePair): string;
    /**
     * 方法身份键：file + class + method + startLine。
     */
    protected getMethodIdentityKey(methodInfo: MethodInfo): string;
    /**
     * 将克隆对转换为 Issue。
     */
    protected addIssueReport(method: MethodInfo, cloneWith: MethodInfo, pair?: ClonePair): void;
    /**
     * 将克隆对按并查集聚合为克隆类并上报。
     */
    protected reportCloneClasses(): void;
    /**
     * 惰性读取配置，避免测试直接调用内部方法时出现未初始化状态。
     */
    private getResolvedOptions;
    /**
     * 强类型配置访问入口。
     */
    protected option<K extends keyof MethodCloneRuleOptions>(key: K): MethodCloneRuleOptions[K];
    /**
     * 计算方法规范化 token 多重集 Jaccard 相似度。
     */
    protected computeJaccardSimilarity(method1: MethodInfo, method2: MethodInfo): number;
    /**
     * 近似克隆检测：基于长度约束 + 相似度阈值。
     */
    protected findNearMissClones(threshold: number): void;
    /**
     * 是否为纯日志语句（默认委托 shared 工具）。
     */
    protected isLogStatement(stmt: Stmt): boolean;
    /**
     * 语句过滤入口；当前只处理 ignoreLogs。
     */
    protected filterStatements(stmts: Stmt[]): Stmt[];
}
//# sourceMappingURL=CodeCloneBaseCheck.d.ts.map