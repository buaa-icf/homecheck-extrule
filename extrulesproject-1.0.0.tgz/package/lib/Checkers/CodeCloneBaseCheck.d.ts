import { ArkFile, ArkMethod, Stmt } from "arkanalyzer";
import { BaseMetaData, Rule, MatcherCallback, IssueReport, AdviceChecker } from "homecheck";
import { MethodCloneRuleOptions } from "./config/types";
/**
 * 方法信息，用于克隆检测
 */
export interface MethodInfo {
    method: ArkMethod;
    filePath: string;
    className: string;
    methodName: string;
    startLine: number;
    endLine: number;
    hash: string;
    normalizedContent: string;
    normalizedTokens: string[];
    tokenMultiset?: Map<string, number>;
    stmtCount: number;
}
/**
 * 克隆对信息
 */
export interface ClonePair {
    method1: MethodInfo;
    method2: MethodInfo;
    /** 相似度（1.0 = 完全相同，< 1.0 = 近似克隆） */
    similarity?: number;
}
/**
 * Code Clone 检测基类
 *
 * 提供克隆检测的通用逻辑：
 * - 方法收集
 * - 哈希分组
 * - 克隆对查找
 * - 问题报告
 *
 * 子类需要实现：
 * - metaData: 规则元数据
 * - getCloneType(): 克隆类型标识
 * - computeHash(): 计算方法的哈希值
 * - getDescription(): 生成问题描述
 */
export declare abstract class CodeCloneBaseCheck implements AdviceChecker {
    abstract readonly metaData: BaseMetaData;
    rule: Rule;
    issues: IssueReport[];
    arkFiles: ArkFile[];
    protected readonly DEFAULT_MIN_STMTS = 5;
    protected readonly DEFAULT_MIN_COMPLEXITY = 0;
    protected readonly DEFAULT_SIMILARITY_THRESHOLD = 1;
    protected readonly DEFAULT_ENABLE_CLONE_CLASSES = false;
    protected readonly defaultOptions: MethodCloneRuleOptions;
    protected options: MethodCloneRuleOptions;
    protected optionsInitialized: boolean;
    protected methodsByHash: Map<string, MethodInfo[]>;
    protected collectedMethodKeys: Set<string>;
    protected reportedPairs: Set<string>;
    protected collectedPairs: ClonePair[];
    private fileMatcher;
    /**
     * 获取克隆类型标识（如 "Type-1", "Type-2"）
     */
    protected abstract getCloneType(): string;
    /**
     * 计算方法的哈希值和规范化内容（子类实现不同的规范化策略）
     * 返回 { hash, normalizedContent } 用于哈希碰撞验证
     */
    protected abstract computeHash(stmts: Stmt[]): {
        hash: string;
        normalizedContent: string;
    };
    /**
     * 生成问题描述（子类可覆盖）
     */
    protected getDescription(method: MethodInfo, cloneWith: MethodInfo, pair?: ClonePair): string;
    /**
     * 检测前初始化
     */
    beforeCheck(): void;
    /**
     * 空的 check 方法（实际检测在 collectMethods 和 afterCheck 中完成）
     */
    check: () => void;
    registerMatchers(): MatcherCallback[];
    /**
     * 收集文件中的所有方法
     */
    collectMethods: (arkFile: ArkFile) => void;
    /**
     * 检测完成后调用，查找克隆对
     */
    afterCheck(): void;
    /**
     * 提取方法信息
     */
    protected extractMethodInfo(method: ArkMethod, filePath: string, className: string): MethodInfo | null;
    /**
     * 基础规范化：去除位置相关信息
     */
    protected normalizeBasic(text: string): string;
    /**
     * DJB2 哈希函数
     */
    protected simpleHash(str: string): string;
    /**
     * 获取方法结束行号
     */
    protected getMethodEndLine(method: ArkMethod): number;
    /**
     * 将方法添加到哈希表
     */
    protected addMethodToHash(methodInfo: MethodInfo): void;
    /**
     * 查找克隆对并上报
     */
    protected findClonePairs(): void;
    /**
     * 上报克隆对
     */
    protected reportClonePair(pair: ClonePair): void;
    /**
     * 生成克隆对的唯一标识
     */
    protected getPairKey(pair: ClonePair): string;
    protected getMethodIdentityKey(methodInfo: MethodInfo): string;
    /**
     * 添加问题报告
     */
    protected addIssueReport(method: MethodInfo, cloneWith: MethodInfo, pair?: ClonePair): void;
    /**
     * 将收集到的克隆对分组为克隆类并上报
     *
     * 使用 Union-Find 将共享克隆关系的方法分为等价类。
     * 每个等价类作为一条克隆类报告。
     */
    protected reportCloneClasses(): void;
    /**
     * 从配置中获取最小语句数阈值
     */
    protected getOptions(): MethodCloneRuleOptions;
    /**
     * 从配置中获取最小语句数阈值
     */
    protected getMinStmts(): number;
    /**
     * 从配置中获取是否忽略字面量差异
     *
     * 注意：此选项默认关闭，因为开启后可能产生误报
     * 详见 test/sample/CodeClone/README.md 中的说明
     *
     * 使用方式：在 ruleConfig.json 中配置
     * "@extrulesproject/code-clone-type2-check": ["error", { "ignoreLiterals": true }]
     */
    protected getIgnoreLiterals(): boolean;
    /**
     * 从配置中获取是否忽略日志语句
     *
     * 日志语句（console.log、hilog、Logger 等）通常只是调试信息，
     * 不影响业务逻辑，因此默认跳过以减少噪声。
     *
     * 使用方式：在 ruleConfig.json 中配置
     * "@extrulesproject/code-clone-type1-check": ["error", { "ignoreLogs": false }]
     *
     * 默认值：true（开启日志过滤）
     */
    protected getIgnoreLogs(): boolean;
    /**
     * 从配置中获取是否忽略类型注解
     *
     * 类型注解（: string, : number, as Type 等）在 Type-1/Type-2 检测中
     * 可能导致仅类型不同的方法被认为不同。开启后可减少此类误报。
     *
     * 默认值：false（不忽略）
     */
    protected getIgnoreTypes(): boolean;
    /**
     * 从配置中获取是否忽略装饰器
     *
     * 装饰器（@Component, @State 等）在 ArkTS 中广泛使用，
     * 可能导致仅装饰器不同的方法被认为不同。开启后可减少此类误报。
     *
     * 默认值：false（不忽略）
     */
    protected getIgnoreDecorators(): boolean;
    /**
     * 从配置中获取最小复杂度阈值
     *
     * 复杂度以方法规范化内容中不同 token 的数量衡量。
     * 低于阈值的方法被认为过于简单（如纯 getter/setter），将被跳过。
     *
     * 默认值：0（禁用，不过滤任何方法）
     */
    protected getMinComplexity(): number;
    /**
     * 从配置中获取近似克隆相似度阈值
     *
     * 设为 1.0 时仅报告完全相同的克隆（默认行为）。
     * 设为 0.8 时，还会报告 80% 以上相似的方法对。
     *
     * 默认值：1.0（禁用近似克隆检测，保持向后兼容）
     */
    protected getSimilarityThreshold(): number;
    /**
     * 从配置中获取是否启用克隆类分组
     *
     * 默认值：false（不启用）
     */
    protected getEnableCloneClasses(): boolean;
    /**
     * 计算两个规范化内容的 Jaccard 相似度
     *
     * 将内容按 '|' 分割为 token 多重集合，
     * 计算 Σmin(count1, count2) / Σmax(count1, count2)。
     *
     * @param method1 方法 1
     * @param method2 方法 2
     * @returns 相似度 [0, 1]
     */
    protected computeJaccardSimilarity(method1: MethodInfo, method2: MethodInfo): number;
    /**
     * 查找近似克隆对
     *
     * 收集所有方法，按语句数进行长度比率分桶（±20%），
     * 对桶内的方法对计算 Jaccard 相似度，
     * 相似度 ≥ threshold 且 < 1.0 的对报告为近似克隆。
     *
     * @param threshold 相似度阈值
     */
    protected findNearMissClones(threshold: number): void;
    /**
     * 判断语句是否为纯日志语句
     *
     * 只过滤"纯日志语句"，即整行代码只有日志调用，没有其他业务逻辑。
     * 如果日志调用嵌在复杂表达式中（如 doSomething() && console.log("done")），
     * 则不跳过该语句，以避免漏掉业务逻辑。
     *
     * 支持的日志模式：
     * - console.* (console.log, console.info, console.warn, console.error, console.debug)
     * - hilog.* (HarmonyOS 系统日志)
     * - Logger.* (项目自定义封装)
     */
    protected isLogStatement(stmt: Stmt): boolean;
    /**
     * 过滤语句列表，移除日志语句
     *
     * 如果配置了 ignoreLogs: true（默认），则过滤掉纯日志语句
     */
    protected filterStatements(stmts: Stmt[]): Stmt[];
}
//# sourceMappingURL=CodeCloneBaseCheck.d.ts.map