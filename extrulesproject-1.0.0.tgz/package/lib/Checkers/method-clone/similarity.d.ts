export declare function buildTokenMultiset(tokens: string[]): Map<string, number>;
export declare function jaccardSimilarityFromMultisets(set1: Map<string, number>, set2: Map<string, number>): number;
//# sourceMappingURL=similarity.d.ts.map