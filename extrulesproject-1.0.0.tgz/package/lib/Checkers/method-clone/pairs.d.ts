import { ClonePair, MethodInfo } from "./types";
/**
 * 从 hash 桶中提取精确克隆对：
 * 先按 normalizedContent 二次分组，再组内两两配对。
 */
export declare function collectExactClonePairs(methodsByHash: Map<string, MethodInfo[]>): ClonePair[];
/**
 * 基于长度比例和相似度函数提取近似克隆对。
 */
export declare function collectNearMissClonePairs(methodsByHash: Map<string, MethodInfo[]>, threshold: number, similarityCalculator: (method1: MethodInfo, method2: MethodInfo) => number): ClonePair[];
//# sourceMappingURL=pairs.d.ts.map