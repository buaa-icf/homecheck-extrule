export interface MethodCloneLocation {
    filePath: string;
    className: string;
    methodName: string;
    startLine: number;
    endLine: number;
}
export declare function formatMethodCloneAnchor(method: MethodCloneLocation): string;
export declare function formatMethodCloneTarget(method: MethodCloneLocation, useFullPath?: boolean): string;
export declare function formatMethodCloneMembers<TMember extends MethodCloneLocation>(members: TMember[]): string;
//# sourceMappingURL=reporting.d.ts.map