export interface CloneMethodIdentity {
    filePath: string;
    methodName: string;
}
export declare function getPairKey(method1: CloneMethodIdentity, method2: CloneMethodIdentity): string;
//# sourceMappingURL=pairKey.d.ts.map