export interface MethodCloneMember {
    filePath: string;
    className: string;
    methodName: string;
    startLine: number;
    endLine: number;
}
export interface MethodCloneClass<TMember extends MethodCloneMember> {
    classId: number;
    members: TMember[];
}
interface MethodClonePair<TMember extends MethodCloneMember> {
    method1: TMember;
    method2: TMember;
}
export declare function classifyMethodClonePairs<TMember extends MethodCloneMember>(pairs: MethodClonePair<TMember>[]): Array<MethodCloneClass<TMember>>;
export {};
//# sourceMappingURL=cloneClasses.d.ts.map