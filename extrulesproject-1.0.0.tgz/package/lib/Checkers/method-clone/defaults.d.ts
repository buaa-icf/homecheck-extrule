import { RuleOptionSchema } from "../config/parseRuleOptions";
import { MethodCloneRuleOptions } from "../config/types";
export declare const DEFAULT_METHOD_CLONE_OPTIONS: MethodCloneRuleOptions;
export declare const METHOD_CLONE_OPTIONS_SCHEMA: RuleOptionSchema<MethodCloneRuleOptions>;
//# sourceMappingURL=defaults.d.ts.map