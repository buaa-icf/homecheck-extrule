import { ArkMethod } from "arkanalyzer";
import { BaseMetaData, BaseChecker, Rule, MatcherCallback, IssueReport } from "homecheck";
/**
 * Long Method 检测规则
 *
 * 检测方法是否过长，过长的方法通常存在以下问题：
 * 1. 难以理解和维护
 * 2. 包含多个职责，违反单一职责原则
 * 3. 难以测试和复用
 *
 * 阈值策略：
 * - 普通函数：默认 50 个语句节点
 * - UI 组装/渲染/构建类函数（build、@Builder、含 ViewTree 的方法等）：
 *   - 软阈值：80 个语句节点（severity 降为 warning）
 *   - 硬阈值：120 个语句节点（保持原 severity）
 *
 * 可通过 ruleConfig.json 配置各阈值参数
 */
export declare class LongMethodCheck implements BaseChecker {
    readonly metaData: BaseMetaData;
    rule: Rule;
    issues: IssueReport[];
    private readonly DEFAULT_MAX_STMTS;
    private readonly DEFAULT_MAX_UI_STMTS_SOFT;
    private readonly DEFAULT_MAX_UI_STMTS_HARD;
    private readonly defaultOptions;
    private options;
    private optionsInitialized;
    private methodMatcher;
    beforeCheck(): void;
    private getOptions;
    registerMatchers(): MatcherCallback[];
    check: (targetMtd: ArkMethod) => void;
    private checkNormalMethod;
    private checkUIMethod;
    /**
     * 判断方法是否为 UI 组装/渲染/构建类方法
     *
     * 满足以下任一条件即视为 UI 方法：
     * 1. 方法本身带有 @Builder 装饰器
     * 2. 方法关联了 ViewTree（UI 渲染树）
     * 3. 方法名为 build 且所属类为 STRUCT（@Component struct 的 build 方法）
     * 4. 方法名为 UI 生命周期方法且所属类为 @Component struct
     */
    private isUIMethod;
    /**
     * 从配置中获取普通方法的最大语句数阈值
     */
    private getMaxStmtsFromConfig;
    private getUIThresholdsFromConfig;
    /**
     * 计算方法的语句数量
     * CFG 中的 stmts 已经包含了方法的所有语句（包括嵌套语句）
     */
    private countMethodStmts;
    private addIssueReport;
}
//# sourceMappingURL=LongMethodCheck.d.ts.map