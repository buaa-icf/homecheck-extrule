import { ArkMethod } from "arkanalyzer";
import { BaseMetaData, MatcherCallback } from "homecheck";
import { RuleOptionSchema } from "./config/parseRuleOptions";
import { LongMethodRuleOptions } from "./config/types";
import { BaseRuleChecker } from "./BaseRuleChecker";
/**
 * Long Method 检测规则
 *
 * 检测方法是否过长，过长的方法通常存在以下问题：
 * 1. 难以理解和维护
 * 2. 包含多个职责，违反单一职责原则
 * 3. 难以测试和复用
 *
 * 阈值策略：
 * - 普通函数：默认 50 行代码
 * - UI 组装/渲染/构建类函数（build、@Builder、含 ViewTree 的方法等）：
 *   - 软阈值：80 行代码（severity 降为 warning）
 *   - 硬阈值：120 行代码（保持原 severity）
 *
 * 可通过 ruleConfig.json 配置各阈值参数
 */
export declare class LongMethodCheck extends BaseRuleChecker<LongMethodRuleOptions> {
    readonly metaData: BaseMetaData;
    protected readonly optionSchema: RuleOptionSchema<LongMethodRuleOptions>;
    protected readonly defaultOptions: LongMethodRuleOptions;
    private readonly DEFAULT_MAX_LINES;
    private readonly DEFAULT_MAX_UI_LINES_SOFT;
    private readonly DEFAULT_MAX_UI_LINES_HARD;
    private methodMatcher;
    registerMatchers(): MatcherCallback[];
    check: (targetMtd: ArkMethod) => void;
    private checkNormalMethod;
    private checkUIMethod;
    /**
     * 从配置中获取普通方法的最大代码行数阈值
     */
    private getMaxCodeLinesFromConfig;
    private getUIThresholdsFromConfig;
    /**
     * 计算方法的代码行数。
     * 优先使用源码文本统计非空且非纯大括号行；若源码缺失则回退到 CFG 节点数。
     */
    private countMethodCodeLines;
    private addIssueReport;
}
//# sourceMappingURL=LongMethodCheck.d.ts.map