import { FragmentCloneReport } from "../fragment-clone";
export type PriorityLevel = "P1" | "P2" | "P3" | "P4";
export interface PriorityResult {
    priorityScore: number;
    priorityLevel: PriorityLevel;
}
interface ScoreParts {
    maintenanceImpact: number;
    smellSpecificEvidence: number;
    changeAmplification: number;
    comprehensionRisk: number;
    thresholdRatio: number;
}
export declare function thresholdScore(ratio: number): number;
export declare function scorePriority(parts: ScoreParts): PriorityResult;
/** Scores only evidence visible in the source at scan time. */
export declare function scoreLongMethod(source: string, lines: number, limit: number, isUi: boolean): PriorityResult;
export declare function scoreFeatureEnvy(source: string, atfd: number, lda: number, cpfd: number, threshold: number): PriorityResult;
export declare function scoreSwitch(source: string, branches: number, threshold: number, caseLineCounts?: number[]): PriorityResult;
export declare function scoreCodeClone(report: FragmentCloneReport, left: string, right: string, minimumTokens: number): PriorityResult;
export {};
//# sourceMappingURL=PriorityScorer.d.ts.map