import { IssueReport } from "homecheck";
export interface DefectsParams {
    line: number;
    startCol: number;
    endCol: number;
    description: string;
    severity: number;
    ruleId: string;
    filePath: string;
    ruleDocPath: string;
    methodName?: string;
    showIgnoreIcon?: boolean;
    disabled?: boolean;
    checked?: boolean;
    fixable?: boolean;
}
export declare function createIssueReport(params: DefectsParams): IssueReport;
//# sourceMappingURL=issueFactory.d.ts.map