import { ArkMethod } from "arkanalyzer";
import { BaseChecker, BaseMetaData, IssueReport, MatcherCallback, Rule } from "homecheck";
/**
 * Detects "Feature Envy" by comparing call distribution to self vs. foreign classes.
 * Thresholds can be tuned via rule.option[0] (minTotalCalls, minForeignCalls, ratioThreshold).
 */
export declare class FeatureEnvyCheck implements BaseChecker {
    readonly metaData: BaseMetaData;
    rule: Rule;
    issues: IssueReport[];
    private readonly IGNORED_CLASSES;
    private methodMatcher;
    private readonly MIN_TOTAL_CALLS;
    private readonly MIN_FOREIGN_CALLS;
    private readonly RATIO_THRESHOLD;
    private readonly defaultOptions;
    private options;
    private optionsInitialized;
    /**
     * Register the method-level matcher for this checker.
     */
    registerMatchers(): MatcherCallback[];
    beforeCheck(): void;
    /**
     * Analyze a method's call targets and report if dominated by one foreign class.
     */
    check: (targetMtd: ArkMethod) => void;
    /**
     * Resolve thresholds, falling back to defaults if rule options are missing.
     */
    private getThresholds;
    /**
     * Collect invoke expressions from a statement (best-effort across stmt/expr shapes).
     */
    private collectInvokes;
    /**
     * Filter out common built-in types to reduce noise.
     */
    private isIgnoredClass;
    /**
     * Emit an IssueReport describing the detected Feature Envy.
     */
    private addIssueReport;
}
//# sourceMappingURL=FeatureEnvyCheck.d.ts.map