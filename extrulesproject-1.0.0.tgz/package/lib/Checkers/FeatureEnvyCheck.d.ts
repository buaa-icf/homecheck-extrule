import { ArkMethod } from "arkanalyzer";
import { BaseMetaData, MatcherCallback } from "homecheck";
import { RuleOptionSchema } from "./config/parseRuleOptions";
import { FeatureEnvyRuleOptions } from "./config/types";
import { BaseRuleChecker } from "./BaseRuleChecker";
/**
 * Detects "Feature Envy" by comparing call distribution to self vs. foreign classes.
 * Thresholds can be tuned via rule.option[0] (minTotalCalls, minForeignCalls, ratioThreshold).
 */
export declare class FeatureEnvyCheck extends BaseRuleChecker<FeatureEnvyRuleOptions> {
    readonly metaData: BaseMetaData;
    protected readonly optionSchema: RuleOptionSchema<FeatureEnvyRuleOptions>;
    protected readonly defaultOptions: FeatureEnvyRuleOptions;
    private readonly IGNORED_CLASSES;
    private methodMatcher;
    /**
     * Register the method-level matcher for this checker.
     */
    registerMatchers(): MatcherCallback[];
    /**
     * Analyze a method's call targets and report if dominated by one foreign class.
     */
    check: (targetMtd: ArkMethod) => void;
    /**
     * Collect invoke expressions from a statement (best-effort across stmt/expr shapes).
     */
    private collectInvokes;
    /**
     * Filter out common built-in types to reduce noise.
     */
    private isIgnoredClass;
    /**
     * Emit an IssueReport describing the detected Feature Envy.
     */
    private addIssueReport;
}
//# sourceMappingURL=FeatureEnvyCheck.d.ts.map