import { ArkMethod } from "arkanalyzer";
import { BaseMetaData, MatcherCallback } from "homecheck";
import { RuleOptionSchema } from "./config/parseRuleOptions";
import { FeatureEnvyRuleOptions } from "./config/types";
import { BaseRuleChecker } from "./BaseRuleChecker";
/**
 * Detects "Feature Envy" through ATFD/LDA/CPFD metrics recovered from CFG statements.
 */
export declare class FeatureEnvyCheck extends BaseRuleChecker<FeatureEnvyRuleOptions> {
    readonly metaData: BaseMetaData;
    protected readonly optionSchema: RuleOptionSchema<FeatureEnvyRuleOptions>;
    protected readonly defaultOptions: FeatureEnvyRuleOptions;
    private methodMatcher;
    /**
     * Register the method-level matcher for this checker.
     */
    registerMatchers(): MatcherCallback[];
    /**
     * Analyze a method's call targets and report if dominated by one foreign class.
     */
    check: (targetMtd: ArkMethod) => void;
    private getMethodPosition;
    /**
     * Emit an IssueReport describing the detected Feature Envy.
     */
    private addIssueReport;
}
//# sourceMappingURL=FeatureEnvyCheck.d.ts.map