import { ArkFile } from "arkanalyzer";
import { BaseMetaData, Rule, MatcherCallback, IssueReport, AdviceChecker } from "homecheck";
import { FragmentCloneDiagnostics } from "./fragment-clone";
/**
 * 克隆范围枚举
 */
export declare enum CloneScope {
    /** 同一方法内的两段相同代码 */
    SAME_METHOD = "SAME_METHOD",
    /** 同一类的不同方法中有相同代码 */
    SAME_CLASS = "SAME_CLASS",
    /** 不同类或顶级函数 */
    DIFFERENT_CLASS = "DIFFERENT_CLASS"
}
/**
 * 代码位置信息（含方法/类归属）
 */
export interface CodeLocation {
    file: string;
    startLine: number;
    endLine: number;
    className?: string;
    methodName?: string;
}
/**
 * 片段级克隆报告
 */
export interface FragmentCloneReport {
    /** 克隆类型：根据规范化配置决定 */
    cloneType: 'Type-1' | 'Type-2' | 'Type-3';
    /** 克隆范围 */
    scope: CloneScope;
    /** 位置 1 */
    location1: CodeLocation;
    /** 位置 2 */
    location2: CodeLocation;
    /** Token 数量 */
    tokenCount: number;
    /** 行数 */
    lineCount: number;
    /** 近似克隆相似度（仅 Type-3 报告有值） */
    similarity?: number;
}
/**
 * 片段级克隆类报告
 */
export interface FragmentCloneClassReport {
    cloneType: 'Type-1' | 'Type-2' | 'Type-3';
    scope: CloneScope;
    classId: number;
    members: CodeLocation[];
}
/**
 * 代码片段级克隆检测规则
 *
 * 使用 Token 级别的滑动窗口算法检测代码克隆，
 * 可以发现方法内部、跨方法、跨文件的重复代码。
 */
export declare class CodeCloneFragmentCheck implements AdviceChecker {
    readonly metaData: BaseMetaData;
    rule: Rule;
    issues: IssueReport[];
    arkFiles: ArkFile[];
    private options;
    private optionsInitialized;
    private diagnostics;
    private cloneMatcher;
    private cloneMerger;
    private tokenizer;
    private fileTokenCache;
    private fileCache;
    private fileMatcher;
    constructor();
    /**
     * 检测前初始化
     */
    beforeCheck(): void;
    /**
     * 空的 check 方法
     */
    check: () => void;
    registerMatchers(): MatcherCallback[];
    /**
     * 收集文件的 Token 并处理
     */
    collectTokens: (arkFile: ArkFile) => void;
    /**
     * 检测完成后，生成报告
     */
    afterCheck(): void;
    /**
     * 执行 Type-3 近似克隆检测
     *
     * 使用 NearMissDetector 对缓存的 Token 序列进行两阶段检测：
     * 1. Q-gram 轮廓 Jaccard 预筛选（候选生成）
     * 2. LCS 相似度精确验证
     *
     * @param threshold 相似度阈值
     * @returns 近似克隆列表
     */
    private findNearMissClones;
    private createCloneClassReports;
    /**
     * 创建克隆报告
     */
    private createCloneReport;
    /**
     * 创建近似克隆报告（Type-3）
     */
    private createNearMissReport;
    /**
     * 反查代码位置的方法/类归属
     */
    private resolveCodeLocation;
    /**
     * 获取方法结束行号
     */
    private getMethodEndLine;
    /**
     * 判定克隆范围
     */
    private determineScope;
    /**
     * 判定克隆类型
     */
    private determineCloneType;
    /**
     * 添加问题报告
     */
    private addIssueReport;
    /**
     * 格式化描述信息
     */
    private formatDescription;
    /**
     * 获取范围描述
     */
    private getScopeDescription;
    private determineClassScope;
    private addCloneClassIssueReport;
    /**
     * 格式化位置信息
     *
     * 仅在 message 中显示文件名，避免描述过长。
     * source 文件完整路径由 defect.filePath 单独提供。
     */
    private formatLocation;
    /**
     * 收集 ArkFile 中所有日志语句所占据的行号集合
     *
     * 遍历文件中所有类的所有方法（包括默认类/默认方法，即顶层代码），
     * 对每个方法的 Stmt 列表：
     *   1. 找到日志语句的起始行
     *   2. 用下一条语句的起始行-1 作为结束行（最后一条用方法结束行）
     *   3. 将该范围内所有行号加入集合
     */
    collectLogLines(arkFile: ArkFile): Set<number>;
    /**
     * 将源码中日志语句所在行替换为空行
     *
     * 替换为空行而非删除，以保持行号不变。
     */
    removeLogLines(sourceCode: string, arkFile: ArkFile): string;
    private getOptions;
    private getEnableCloneClasses;
    private getIgnoreLogs;
    private getMinimumTokens;
    private getNormalizeIdentifiers;
    private getNormalizeLiterals;
    private getIgnoreTypes;
    private getIgnoreDecorators;
    /**
     * 从配置中获取最小不同 token 类型数阈值
     *
     * 用于过滤过于简单的文件（例如只包含关键字和标点的简单声明文件）。
     * 只有当文件的 token 类型多样性达到阈值时才进行克隆检测。
     *
     * 默认值：0（禁用，不过滤任何文件）
     */
    private getMinDistinctTokenTypes;
    /**
     * 从配置中获取片段级近似克隆相似度阈值
     *
     * 设为 1.0 时仅报告精确匹配的克隆（默认行为）。
     * 设为 0.7~0.9 时，还会报告对应百分比以上相似的片段（Type-3）。
     *
     * 默认值：1.0（禁用近似克隆检测，保持向后兼容）
     */
    private getSimilarityThreshold;
    getDiagnostics(): FragmentCloneDiagnostics;
}
//# sourceMappingURL=CodeCloneFragmentCheck.d.ts.map