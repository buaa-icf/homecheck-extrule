import { ArkFile } from "arkanalyzer";
import { AdviceChecker, BaseMetaData, IssueReport, MatcherCallback, Rule } from "homecheck";
import { FragmentCloneDiagnostics } from "./fragment-clone";
/**
 * 片段级克隆规则实现。
 *
 * 主要流程：
 * 1. 文件读取与可选日志过滤；
 * 2. Token 化 + 滑窗匹配；
 * 3. 克隆片段合并与去重；
 * 4. 可选近似克隆检测与最终报告。
 */
export declare class CodeCloneFragmentCheck implements AdviceChecker {
    readonly metaData: BaseMetaData;
    rule: Rule;
    issues: IssueReport[];
    arkFiles: ArkFile[];
    private options;
    private diagnostics;
    private cloneMatcher;
    private exactCloneClassBuilder;
    private tokenizer;
    private fileTokenCache;
    private fileCache;
    private locationCache;
    private fileMatcher;
    constructor();
    /**
     * 每轮检测开始时重置配置与缓存状态。
     */
    beforeCheck(): void;
    check: () => void;
    /**
     * 注册 FILE 级回调，逐文件收集 token。
     */
    registerMatchers(): MatcherCallback[];
    /**
     * 读取源码、执行预处理并将 token 送入匹配器。
     */
    collectTokens: (arkFile: ArkFile) => void;
    /**
     * 收尾阶段统一生成 issue。
     */
    afterCheck(): void;
    /** 报告生成后立即释放全仓 Token、哈希索引和 ArkFile 引用。 */
    private releaseScanCaches;
    /**
     * 根据配置构造 Tokenizer。
     */
    private createTokenizer;
    private createCloneMatcher;
    /**
     * 近似克隆（Type-3）检测并做同文件重叠过滤与去重。
     */
    private findNearMissClones;
    private createCloneClassReportsFromMergedClasses;
    /**
     * 精确克隆报告对象构建。
     */
    private createCloneReport;
    /**
     * 近似克隆报告对象构建。
     */
    private createNearMissReport;
    /**
     * 基于缓存 ArkFile 反查片段归属（类/方法）。
     */
    private resolveCodeLocation;
    /**
     * 单条片段克隆 issue 上报。
     */
    private addIssueReport;
    /**
     * 克隆类 issue 上报。
     */
    private addCloneClassIssueReport;
    /**
     * 暴露可观测诊断数据，避免直接泄漏内部数组引用。
     */
    getDiagnostics(): FragmentCloneDiagnostics;
}
//# sourceMappingURL=CodeCloneFragmentCheck.d.ts.map