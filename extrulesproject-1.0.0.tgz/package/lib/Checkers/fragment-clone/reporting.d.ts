import { CodeLocation, CloneScope, FragmentCloneReport } from "./types";
import { FragmentCloneRuleOptions } from "../config/types";
/**
 * 判定两段代码的克隆范围（同方法/同类/跨类）。
 */
export declare function determineScope(loc1: CodeLocation, loc2: CodeLocation): CloneScope;
/**
 * 基于克隆类成员集合判定该类的整体范围。
 */
export declare function determineClassScope(members: CodeLocation[]): CloneScope;
/**
 * 将范围枚举映射为报告描述文本。
 */
export declare function getScopeDescription(scope: CloneScope): string;
/**
 * 格式化代码位置。
 *
 * 约定：左侧可读性优先（文件名），右侧可定位性优先（完整路径）。
 */
export declare function formatLocation(loc: CodeLocation, useFullPath?: boolean): string;
/**
 * 统一格式化片段克隆描述消息。
 */
export declare function formatDescription(report: FragmentCloneReport): string;
/**
 * 根据规范化配置判定 Type-1 / Type-2。
 */
export declare function detectCloneType(options: Pick<FragmentCloneRuleOptions, "normalizeIdentifiers" | "normalizeLiterals">): "Type-1" | "Type-2";
//# sourceMappingURL=reporting.d.ts.map