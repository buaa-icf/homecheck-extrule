import { ArkFile } from "arkanalyzer";
import { CodeLocation } from "./types";
export declare function resolveCodeLocationFromCache(fileCache: Map<string, ArkFile>, file: string, startLine: number, endLine: number): CodeLocation;
//# sourceMappingURL=location.d.ts.map