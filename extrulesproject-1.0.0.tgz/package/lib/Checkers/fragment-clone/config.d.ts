import { Rule } from "homecheck";
import { FragmentCloneRuleOptions } from "../config/types";
export declare const DEFAULT_FRAGMENT_CLONE_OPTIONS: FragmentCloneRuleOptions;
export declare function parseFragmentCloneOptions(rule?: Rule): FragmentCloneRuleOptions;
//# sourceMappingURL=config.d.ts.map