import { MergedClone } from "../FragmentDetection";
import { CodeLocation, FragmentCloneReport } from "./types";
type CloneLike = Pick<MergedClone, "location1" | "location2" | "tokenCount"> & {
    similarity?: number;
};
type LocationResolver = (file: string, startLine: number, endLine: number) => CodeLocation;
export declare function buildFragmentCloneReport(clone: CloneLike, cloneType: "Type-1" | "Type-2" | "Type-3", scopeResolver: (location1: CodeLocation, location2: CodeLocation) => FragmentCloneReport["scope"], resolveLocation: LocationResolver): FragmentCloneReport;
export {};
//# sourceMappingURL=reports.d.ts.map