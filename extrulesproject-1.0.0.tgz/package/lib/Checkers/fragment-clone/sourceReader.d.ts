export interface ReadSourceResult {
    content: string | null;
    errorMessage?: string;
}
export declare function readSourceFile(filePath: string): ReadSourceResult;
//# sourceMappingURL=sourceReader.d.ts.map