import { ArkFile } from "arkanalyzer";
export declare function collectLogLines(arkFile: ArkFile): Set<number>;
export declare function removeLogLines(sourceCode: string, arkFile: ArkFile): string;
export declare function blankSourceLines(sourceCode: string, lineNumbers: Iterable<number>): string;
//# sourceMappingURL=logFilter.d.ts.map