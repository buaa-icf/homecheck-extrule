import { ArkFile } from "arkanalyzer";
export declare function collectLogLines(arkFile: ArkFile): Set<number>;
export declare function removeLogLines(sourceCode: string, arkFile: ArkFile): string;
//# sourceMappingURL=logFilter.d.ts.map