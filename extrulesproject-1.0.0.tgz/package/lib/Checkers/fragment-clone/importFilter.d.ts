/**
 * 将 import 声明替换为空格，同时保留换行和总字符数。
 * 这样 import 不参与克隆 token 窗口，后续报告的原始行列仍保持不变。
 */
export declare function blankImportDeclarations(sourceCode: string, filePath?: string): string;
//# sourceMappingURL=importFilter.d.ts.map