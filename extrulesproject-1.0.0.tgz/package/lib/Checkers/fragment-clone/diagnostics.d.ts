export interface FragmentCloneDiagnostics {
    filesReadFailed: number;
    filesProcessFailed: number;
    errors: Array<{
        filePath: string;
        phase: "read" | "process";
        message: string;
    }>;
}
export declare function createEmptyDiagnostics(): FragmentCloneDiagnostics;
//# sourceMappingURL=diagnostics.d.ts.map