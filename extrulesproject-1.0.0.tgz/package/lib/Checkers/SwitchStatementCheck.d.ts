import { ArkMethod } from "arkanalyzer";
import { BaseMetaData, MatcherCallback } from "homecheck";
import { RuleOptionSchema } from "./config/parseRuleOptions";
import { SwitchStatementRuleOptions } from "./config/types";
import { BaseRuleChecker } from "./BaseRuleChecker";
/**
 * Detects large switch statements and long if / else if chains.
 * Uses CFG statements for switch structure and source scans as fallback/if-chain path.
 */
export declare class SwitchStatementCheck extends BaseRuleChecker<SwitchStatementRuleOptions> {
    readonly metaData: BaseMetaData;
    protected readonly optionSchema: RuleOptionSchema<SwitchStatementRuleOptions>;
    protected readonly defaultOptions: SwitchStatementRuleOptions;
    private methodMatcher;
    /**
     * Register the method-level matcher for this checker.
     */
    registerMatchers(): MatcherCallback[];
    /**
     * Scan a method for switch blocks and if-else chains, reporting those above the threshold.
     *
     * Detection proceeds in three stages:
     * 1. CFG-based switch detection (structural, precise)
     * 2. Source-based switch detection (fallback for switches flattened in CFG)
     * 3. Source-based if-else chain detection (avoids CFG's overlapping ArkIfStmt nodes)
     */
    check: (targetMtd: ArkMethod) => void;
    /**
     * Detect switch statements from CFG statement stream.
     */
    private detectSwitchesFromCfg;
    /**
     * Prefer original source text for accurate brace/case counting.
     */
    private getStmtText;
    /**
     * Fallback scan over raw source to catch switches that CFG misses.
     * De-duplicates with the `reported` key set.
     */
    private detectFromSource;
    /**
     * Detect long if / else if chains from raw source.
     * This path deliberately avoids CFG reconstruction because ArkAnalyzer expands
     * else-if chains into overlapping ArkIfStmt nodes.
     */
    private detectIfElseChainsFromSource;
    /** ArkMethod.getCode() uses method-relative lines; reports must use source-file lines. */
    private toAbsoluteSourceLine;
    /**
     * Resolve the case-count threshold from rule options or defaults.
     */
    private getCaseThreshold;
    /**
     * Report a switch statement issue.
     */
    private addSwitchIssueReport;
    /**
     * Report an if-else chain issue.
     */
    private addIfElseChainIssueReport;
}
//# sourceMappingURL=SwitchStatementCheck.d.ts.map