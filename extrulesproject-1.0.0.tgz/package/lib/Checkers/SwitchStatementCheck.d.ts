import { ArkMethod } from "arkanalyzer";
import { BaseChecker, BaseMetaData, IssueReport, MatcherCallback, Rule } from "homecheck";
/**
 * Detects large switch statements by counting case/default labels.
 * Uses CFG statements for structure and a source scan as a fallback.
 */
export declare class SwitchStatementCheck implements BaseChecker {
    readonly metaData: BaseMetaData;
    rule: Rule;
    issues: IssueReport[];
    private methodMatcher;
    private readonly MIN_CASES;
    private readonly defaultOptions;
    private options;
    private optionsInitialized;
    /**
     * Register the method-level matcher for this checker.
     */
    registerMatchers(): MatcherCallback[];
    beforeCheck(): void;
    private getOptions;
    /**
     * Scan a method for switch blocks and report those above the threshold.
     */
    check: (targetMtd: ArkMethod) => void;
    /**
     * Prefer original source text for accurate brace/case counting.
     */
    private getStmtText;
    /**
     * Basic switch detection on a single line of text.
     */
    private containsSwitch;
    /**
     * Count case/default labels inside a switch block.
     */
    private countCases;
    /**
     * Collect the textual switch block starting at a statement index.
     * Uses brace depth to determine the block end.
     */
    private collectSwitchBlockText;
    /**
     * Fallback scan over raw source to catch switches that CFG misses.
     * De-duplicates with the `reported` key set.
     */
    private detectFromSource;
    /**
     * Create a stable-ish dedupe key for a detected switch block.
     */
    private buildSwitchKey;
    /**
     * Estimate per-case line counts for reporting detail.
     */
    private calculateCaseLineCounts;
    /**
     * Resolve the case-count threshold from rule options or defaults.
     */
    private getCaseThreshold;
    /**
     * Report a switch statement detected from CFG statement context.
     */
    private addIssueReport;
}
//# sourceMappingURL=SwitchStatementCheck.d.ts.map