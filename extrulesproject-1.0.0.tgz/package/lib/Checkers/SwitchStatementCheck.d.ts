import { ArkMethod } from "arkanalyzer";
import { BaseMetaData, MatcherCallback } from "homecheck";
import { RuleOptionSchema } from "./config/parseRuleOptions";
import { SwitchStatementRuleOptions } from "./config/types";
import { BaseRuleChecker } from "./BaseRuleChecker";
/**
 * Detects large switch statements and long if / else if chains.
 * Uses CFG statements for switch structure and source scans as fallback/if-chain path.
 */
export declare class SwitchStatementCheck extends BaseRuleChecker<SwitchStatementRuleOptions> {
    readonly metaData: BaseMetaData;
    protected readonly optionSchema: RuleOptionSchema<SwitchStatementRuleOptions>;
    protected readonly defaultOptions: SwitchStatementRuleOptions;
    /** 同一源码 switch 可能同时属于普通方法和 ArkAnalyzer 生成的匿名方法。 */
    private reportedSwitches;
    private methodMatcher;
    /**
     * Register the method-level matcher for this checker.
     */
    registerMatchers(): MatcherCallback[];
    beforeCheck(): void;
    /**
     * Scan a method for switch blocks and if-else chains, reporting those above the threshold.
     *
     * Detection proceeds in three stages:
     * 1. CFG-based switch detection (structural, precise)
     * 2. Source-based switch detection (fallback for switches flattened in CFG)
     * 3. Source-based if-else chain detection (avoids CFG's overlapping ArkIfStmt nodes)
     */
    check: (targetMtd: ArkMethod) => void;
    /**
     * Detect switch statements from CFG statement stream.
     */
    private detectSwitchesFromCfg;
    /**
     * Prefer original source text for accurate brace/case counting.
     */
    private getStmtText;
    /** Scan raw source so reports are anchored to the actual switch node. */
    private detectFromSource;
    /**
     * 以源码文件和真实 switch 起点作为身份，跨 ArkMethod 去重。
     * 若匿名方法先被派发，后续普通方法会替换其归属，报告行仍是 switch 起始行。
     */
    private reportSwitchOnce;
    /**
     * Detect long if / else if chains from raw source.
     * This path deliberately avoids CFG reconstruction because ArkAnalyzer expands
     * else-if chains into overlapping ArkIfStmt nodes.
     */
    private detectIfElseChainsFromSource;
    /** ArkMethod.getCode() uses method-relative lines; reports must use source-file lines. */
    private toAbsoluteSourceLine;
    /**
     * Resolve the case-count threshold from rule options or defaults.
     */
    private getCaseThreshold;
    /**
     * Report a switch statement issue.
     */
    private addSwitchIssueReport;
    /**
     * Report an if-else chain issue.
     */
    private addIfElseChainIssueReport;
}
//# sourceMappingURL=SwitchStatementCheck.d.ts.map