import { MergedClone } from './CloneMerger';
export interface CloneClassMember {
    file: string;
    startLine: number;
    endLine: number;
    startIndex: number;
    endIndex: number;
}
export interface CloneClass {
    classId: number;
    members: CloneClassMember[];
}
/**
 * 将 MergedClone 列表分组为克隆类
 */
export declare function classifyClones(clones: MergedClone[]): CloneClass[];
//# sourceMappingURL=CloneClassifier.d.ts.map