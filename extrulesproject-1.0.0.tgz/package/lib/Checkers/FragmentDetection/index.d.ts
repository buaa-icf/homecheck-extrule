/**
 * FragmentDetection 模块
 *
 * 代码片段级克隆检测的核心组件
 */
export { Token, TokenType, createToken, isKeyword, isIdentifier, isLiteral } from './Token';
export { TokenWindow, createSlidingWindows, getWindowCount } from './SlidingWindow';
export { FragmentLocation, HashIndex, computeTokensHash, computeFingerprint, createLocationFromWindow } from './HashIndex';
export { djb2Hash } from '../shared';
export { CloneMatch, ClonePair, CloneMatcher, CloneMatcherOptions } from './CloneMatcher';
export { MergedClone, isConsecutive, createMergedClone, extendMergedClone, mergeClonePairs, CloneMerger } from './CloneMerger';
export { UnionFind } from './UnionFind';
export { CloneClass, CloneClassMember, classifyClones } from './CloneClassifier';
export { RollingHash } from './RollingHash';
export { TokenizerOptions, Tokenizer, tokenize, tokenizeNormalized, mapSyntaxKindToTokenType, offsetToLineColumn } from './Tokenizer';
export { lcsLength, lcsSimilarity, buildQGramProfile, qgramJaccard } from './SimilarityScorer';
export { NearMissClone, NearMissDetector } from './NearMissDetector';
export { linesOverlap, filterSelfOverlappingClones, deduplicateMergedClones } from './ClonePipelineUtils';
//# sourceMappingURL=index.d.ts.map