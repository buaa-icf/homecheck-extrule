import { ExactCloneGroup } from './CloneMatcher';
import { MergedClone } from './CloneMerger';
export interface MergedCloneMember {
    file: string;
    startLine: number;
    endLine: number;
    startIndex: number;
    endIndex: number;
}
export interface MergedCloneClass {
    classId: number;
    members: MergedCloneMember[];
    tokenCount: number;
}
export declare class ExactCloneClassBuilder {
    build(groups: ExactCloneGroup[]): MergedCloneClass[];
    toRepresentativeClones(classes: MergedCloneClass[]): MergedClone[];
    private selectMembers;
}
//# sourceMappingURL=ExactCloneClassBuilder.d.ts.map