/**
 * 克隆合并器模块
 *
 * 将连续的克隆匹配合并成更大的克隆区域
 */
import { ClonePair } from './CloneMatcher';
/**
 * 合并后的克隆区域
 */
export interface MergedClone {
    /** 第一个克隆区域 */
    location1: {
        file: string;
        startLine: number;
        endLine: number;
        startIndex: number;
        endIndex: number;
    };
    /** 第二个克隆区域 */
    location2: {
        file: string;
        startLine: number;
        endLine: number;
        startIndex: number;
        endIndex: number;
    };
    /** 合并后的总 Token 数 */
    tokenCount: number;
}
/**
 * 判断两个克隆对是否连续
 *
 * 连续的条件：
 * 1. 来自同一对文件
 * 2. 两个位置的 startIndex 都相差 1
 *
 * @param pair1 第一个克隆对
 * @param pair2 第二个克隆对
 * @returns 是否连续
 */
export declare function isConsecutive(pair1: ClonePair, pair2: ClonePair): boolean;
/**
 * 从克隆对创建初始的合并克隆
 *
 * @param pair 克隆对
 * @param windowSize 窗口大小
 * @returns 合并克隆
 */
export declare function createMergedClone(pair: ClonePair, windowSize: number): MergedClone;
/**
 * 扩展合并克隆（将连续的克隆对合并进来）
 *
 * @param merged 当前合并克隆
 * @param pair 要合并的克隆对
 */
export declare function extendMergedClone(merged: MergedClone, pair: ClonePair): void;
/**
 * 合并克隆对列表
 *
 * 将连续的克隆对合并成更大的克隆区域
 *
 * @param pairs 克隆对列表
 * @param windowSize 窗口大小
 * @returns 合并后的克隆区域列表
 */
export declare function mergeClonePairs(pairs: ClonePair[], windowSize: number): MergedClone[];
/**
 * 克隆合并器类
 *
 * 封装合并逻辑，提供更友好的 API
 */
export declare class CloneMerger {
    private windowSize;
    constructor(windowSize: number);
    /**
     * 合并克隆对
     *
     * @param pairs 克隆对列表
     * @returns 合并后的克隆区域列表
     */
    merge(pairs: ClonePair[]): MergedClone[];
    /**
     * 获取窗口大小
     */
    getWindowSize(): number;
}
//# sourceMappingURL=CloneMerger.d.ts.map