/**
 * 克隆匹配器模块
 *
 * 使用 Rabin-Karp 滚动哈希实现 O(n) 的克隆片段检测和匹配。
 * 指纹验证采用惰性计算，仅在哈希碰撞时才生成指纹。
 */
import { Token } from './Token';
import { FragmentLocation } from './HashIndex';
export interface CloneMatcherOptions {
    maxPairsPerFingerprint?: number;
}
/**
 * 克隆匹配结果
 */
export interface CloneMatch {
    /** 匹配的哈希值 */
    hash: string;
    /** 所有匹配的位置（至少 2 个） */
    locations: FragmentLocation[];
}
/**
 * 克隆片段对
 */
export interface ClonePair {
    /** 第一个片段的位置 */
    location1: FragmentLocation;
    /** 第二个片段的位置 */
    location2: FragmentLocation;
    /** 匹配的 Token 数量 */
    tokenCount: number;
}
/**
 * 克隆匹配器
 *
 * 使用 Rabin-Karp 滚动哈希 + 惰性指纹验证检测代码克隆。
 * 相比旧的 O(n*k) 滑动窗口方案，哈希计算降为 O(n)。
 */
export declare class CloneMatcher {
    /** 哈希索引 */
    private hashIndex;
    /** 窗口大小（最小重复 Token 数） */
    private windowSize;
    /** Token 词汇表：token value → 整数 ID */
    private tokenVocab;
    /** 每个文件的 Token 序列引用（用于惰性指纹计算） */
    private fileTokens;
    /** 单个规范化指纹最多展开的候选克隆对数量 */
    private readonly maxPairsPerFingerprint;
    /**
     * 构造函数
     *
     * @param windowSize 窗口大小，默认 100
     */
    constructor(windowSize?: number, options?: CloneMatcherOptions);
    /**
     * 将 Token 值映射为整数 ID
     *
     * @param tokenValue Token 的值
     * @returns 整数 ID
     */
    private getTokenId;
    /**
     * 处理单个文件的 Token 序列
     *
     * 使用 Rabin-Karp 滚动哈希在 O(n) 时间内计算所有窗口哈希，
     * 不再需要逐个创建滑动窗口。指纹验证延迟到 getClonePairs() 阶段。
     *
     * @param tokens Token 序列
     * @param file 文件路径
     */
    processFile(tokens: Token[], file: string): void;
    /**
     * 获取所有克隆匹配
     *
     * @returns 克隆匹配列表
     */
    getMatches(): CloneMatch[];
    /**
     * 获取所有克隆对
     *
     * 惰性指纹验证：仅当同一哈希值下有多个位置时，
     * 才计算 tokenFingerprint 进行碰撞排除。
     *
     * @returns 克隆对列表
     */
    getClonePairs(): ClonePair[];
    /**
     * 解析位置的 Token 指纹
     *
     * 如果已有 tokenFingerprint 则直接使用，
     * 否则从 allTokens 惰性计算。
     */
    private resolveFingerprint;
    /**
     * 获取索引大小
     */
    getIndexSize(): number;
    /**
     * 清空索引
     */
    clear(): void;
    /**
     * 获取窗口大小
     */
    getWindowSize(): number;
}
//# sourceMappingURL=CloneMatcher.d.ts.map