/**
 * 滚动哈希模块
 *
 * 基于 Rabin-Karp 实现 Token 序列的 O(1) 窗口滑动哈希。
 * 使用双哈希降低碰撞概率。
 */
/**
 * 滚动哈希类
 */
export declare class RollingHash {
    /** 第一个哈希值 */
    private hash1;
    /** 第二个哈希值 */
    private hash2;
    /** 第一个哈希的基数 */
    private readonly base1;
    /** 第二个哈希的基数 */
    private readonly base2;
    /** 第一个哈希的模数 */
    private readonly mod1;
    /** 第二个哈希的模数 */
    private readonly mod2;
    /** 窗口大小 */
    private readonly windowSize;
    /** base1^(windowSize-1) % mod1 */
    private readonly pow1;
    /** base2^(windowSize-1) % mod2 */
    private readonly pow2;
    /**
     * 构造函数
     *
     * @param windowSize 窗口大小
     */
    constructor(windowSize: number);
    /**
     * 初始化首个窗口哈希
     *
     * @param tokenIds 首个窗口的 Token ID 列表
     * @returns 组合哈希键
     */
    init(tokenIds: number[]): string;
    /**
     * 从完整 Token ID 数组的指定窗口初始化哈希，避免调用方复制首窗口数组。
     *
     * @param tokenIds 完整 Token ID 序列
     * @param startIndex 窗口起始位置
     * @returns 组合哈希键
     */
    initWindow(tokenIds: number[], startIndex: number): string;
    /**
     * 滑动窗口并更新哈希
     *
     * @param removeId 被移出窗口的 Token ID
     * @param addId 新加入窗口的 Token ID
     * @returns 组合哈希键
     */
    slide(removeId: number, addId: number): string;
    /**
     * 正整数 Token ID 的快速滑动路径。
     *
     * CloneMatcher 生成的 Token ID 始终为正整数，因此可以少做负数规范化。
     */
    slidePositive(removeId: number, addId: number): string;
    /**
     * 获取当前哈希键
     */
    getHashKey(): string;
    /**
     * 计算 (a * b) % mod
     */
    private mulMod;
    /**
     * 计算 base^exp % mod
     */
    private computePower;
    /**
     * 将值规范到 [0, mod) 范围
     */
    private normalizeMod;
}
//# sourceMappingURL=RollingHash.d.ts.map