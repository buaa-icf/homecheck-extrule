/**
 * 近似克隆检测器模块
 *
 * 实现 Type-3 片段级近似克隆检测，采用两阶段策略：
 * 1. 候选生成：Q-gram 轮廓 Jaccard 预筛选（O(n+m)）
 * 2. 精确验证：LCS 相似度计算（O(n*m)）
 *
 * 将文件的 Token 序列分块为固定大小、半重叠步长的块，
 * 跨块对比寻找近似匹配。
 */
import { Token } from './Token';
import { MergedClone } from './CloneMerger';
/**
 * 近似克隆结果，扩展自 MergedClone
 */
export interface NearMissClone extends MergedClone {
    /** LCS 相似度 [0, 1]，仅 < 1.0 的对会被报告 */
    similarity: number;
}
/**
 * 近似克隆检测器
 *
 * 使用 Q-gram 预筛选 + LCS 精确验证的两阶段策略。
 * 默认 Q-gram 大小为 5，预筛选比率为 0.7（即 Q-gram 阈值 = similarityThreshold × 0.7）。
 */
export declare class NearMissDetector {
    /** 窗口大小（块大小） */
    private readonly windowSize;
    /** 最终相似度阈值 */
    private readonly similarityThreshold;
    /** Q-gram 大小 */
    private readonly qgramSize;
    /** 预筛选比率 */
    private readonly preFilterRatio;
    /** 已注册的 Token 块列表 */
    private blocks;
    /**
     * 构造函数
     *
     * @param windowSize 窗口大小（块大小）
     * @param similarityThreshold 最终相似度阈值
     * @param qgramSize Q-gram 大小，默认 5
     */
    constructor(windowSize: number, similarityThreshold: number, qgramSize?: number);
    /**
     * 注册文件的 Token 序列
     *
     * 将 Token 序列分块为大小为 windowSize、步长为 windowSize/2 的重叠块。
     *
     * @param tokens Token 序列
     * @param file 文件路径
     */
    addFile(tokens: Token[], file: string): void;
    /**
     * 执行近似克隆检测
     *
     * 两阶段策略：
     * 1. 为所有块构建 Q-gram 轮廓
     * 2. 两两比较：先 Q-gram Jaccard 预筛选，通过后 LCS 精确验证
     * 3. 过滤掉完全相同的对（由精确匹配器处理）
     *
     * @returns 近似克隆列表
     */
    detect(): NearMissClone[];
    /**
     * 清空检测器状态
     */
    clear(): void;
}
//# sourceMappingURL=NearMissDetector.d.ts.map