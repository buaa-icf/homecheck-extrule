/**
 * 克隆检测管线共享工具
 *
 * 提供方法级和片段级克隆检测共用的去重、重叠判断等逻辑，
 * 减少两条管线之间的代码重复。
 */
import { MergedClone } from './CloneMerger';
/**
 * 判断两个行范围是否重叠
 *
 * @param s1 范围1起始行
 * @param e1 范围1结束行
 * @param s2 范围2起始行
 * @param e2 范围2结束行
 * @returns 是否重叠
 */
export declare function linesOverlap(s1: number, e1: number, s2: number, e2: number): boolean;
/**
 * 过滤同文件自身重叠克隆
 *
 * 同文件内行范围重叠的克隆对属于自身克隆误报，应该排除。
 *
 * @param clones 合并后的克隆列表
 * @returns 过滤后的列表
 */
export declare function filterSelfOverlappingClones(clones: MergedClone[]): MergedClone[];
/**
 * 去重合并克隆：同一文件对、行范围重叠的克隆只保留 tokenCount 最大的
 *
 * 算法：
 * 1. 按文件对和起始行排序，tokenCount 大的排前面
 * 2. 顺序遍历，跳过与已有结果行范围重叠的克隆
 *
 * @param clones 合并后的克隆列表
 * @returns 去重后的列表
 */
export declare function deduplicateMergedClones(clones: MergedClone[]): MergedClone[];
//# sourceMappingURL=ClonePipelineUtils.d.ts.map