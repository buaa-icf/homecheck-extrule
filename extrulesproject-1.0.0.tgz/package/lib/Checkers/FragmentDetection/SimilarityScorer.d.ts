/**
 * 相似度计算模块
 *
 * 提供 Token 序列间的相似度计算算法，用于 Type-3 近似克隆检测。
 *
 * 算法：
 * - LCS（最长公共子序列）：精确但 O(n*m)，用于验证阶段
 * - Q-gram 轮廓 Jaccard：O(n+m)，用于候选筛选阶段
 */
/**
 * 计算两个序列的 LCS 长度
 *
 * 使用空间优化的动态规划，空间 O(min(n,m))。
 *
 * @param seq1 序列 1
 * @param seq2 序列 2
 * @returns LCS 长度
 */
export declare function lcsLength(seq1: string[], seq2: string[]): number;
/**
 * 计算两个 Token 序列的 LCS 相似度
 *
 * 公式：2 * LCS(a, b) / (|a| + |b|)
 * 范围：[0, 1]，1.0 = 完全相同
 *
 * @param seq1 序列 1
 * @param seq2 序列 2
 * @returns 相似度 [0, 1]
 */
export declare function lcsSimilarity(seq1: string[], seq2: string[]): number;
/**
 * 构建 Q-gram 轮廓
 *
 * 将 Token 序列切分为长度为 q 的连续子序列，
 * 统计每个子序列出现的次数。
 *
 * @param tokens Token 值序列
 * @param q q-gram 大小
 * @returns q-gram → 出现次数
 */
export declare function buildQGramProfile(tokens: string[], q: number): Map<string, number>;
/**
 * 计算两个 Q-gram 轮廓的 Jaccard 相似度
 *
 * 使用多重集合 Jaccard：Σmin / Σmax
 *
 * @param profile1 轮廓 1
 * @param profile2 轮廓 2
 * @returns 相似度 [0, 1]
 */
export declare function qgramJaccard(profile1: Map<string, number>, profile2: Map<string, number>): number;
//# sourceMappingURL=SimilarityScorer.d.ts.map