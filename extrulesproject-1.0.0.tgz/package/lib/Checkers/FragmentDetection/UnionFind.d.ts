/**
 * Union-Find（并查集）数据结构
 *
 * 用于将克隆对分组为等价类（克隆类）。
 */
export declare class UnionFind {
    private parent;
    private rank;
    /**
     * 查找节点所在集合的根（带路径压缩）
     */
    find(x: string): string;
    /**
     * 合并两个节点所在的集合（按秩合并）
     */
    union(x: string, y: string): void;
    /**
     * 获取所有等价类分组
     */
    getGroups(): Map<string, string[]>;
}
//# sourceMappingURL=UnionFind.d.ts.map