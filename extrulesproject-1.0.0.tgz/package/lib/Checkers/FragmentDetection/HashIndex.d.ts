/**
 * 哈希索引模块
 *
 * 实现窗口哈希计算和索引存储
 */
import { Token } from './Token';
import { TokenWindow } from './SlidingWindow';
/**
 * 片段位置信息
 */
export interface FragmentLocation {
    /** 所属文件路径 */
    file: string;
    /** 在全局 Token 序列中的起始索引 */
    startIndex: number;
    /** 起始行号 */
    startLine: number;
    /** 结束行号 */
    endLine: number;
    /** Token 指纹（规范化后的 Token 序列拼接），用于哈希碰撞验证 */
    tokenFingerprint?: string;
    /** 可选 Token ID 序列引用（兼容手工构造 location；主路径使用文件级缓存） */
    tokenIds?: number[];
    /** 可选 Token 序列引用（兼容手工构造 location；主路径使用文件级缓存） */
    allTokens?: Token[];
}
/**
 * 哈希索引类
 *
 * 存储每个哈希值对应的所有位置
 */
export declare class HashIndex {
    /** 哈希值 → 紧凑位置索引；单次出现时不提前分配数组 */
    private index;
    private files;
    private startIndexes;
    private startLines;
    private endLines;
    private tokenFingerprints;
    private tokenIdRefs;
    private tokenRefs;
    /**
     * 添加一个位置到索引
     *
     * @param hash 哈希值
     * @param location 位置信息
     */
    add(hash: string, location: FragmentLocation): void;
    /**
     * 添加一个未物化的窗口位置到索引。
     *
     * CloneMatcher 热路径会为每个滑动窗口调用这里；多数窗口不会成为重复候选，
     * 因此先存储紧凑字段，直到 get()/getDuplicates() 再物化 FragmentLocation。
     */
    addWindow(hash: string, file: string, startIndex: number, startLine: number, endLine: number): void;
    private addStoredLocation;
    /**
     * 获取某个哈希值对应的所有位置
     *
     * @param hash 哈希值
     * @returns 位置列表，如果不存在则返回空数组
     */
    get(hash: string): FragmentLocation[];
    /**
     * 获取所有有重复的哈希值（位置数 >= 2）
     *
     * @returns [哈希值, 位置列表] 的数组
     */
    getDuplicates(): [string, FragmentLocation[]][];
    /**
     * 获取索引大小（不同哈希值的数量）
     */
    size(): number;
    /**
     * 清空索引
     */
    clear(): void;
    private toLocation;
}
/**
 * 计算指定窗口范围的 Token 指纹
 *
 * 仅拼接 Token 的 value 字段，保持与历史逻辑一致。
 *
 * @param tokens 完整 Token 序列
 * @param startIndex 窗口起始索引
 * @param windowSize 窗口大小
 * @returns 指纹字符串
 */
export declare function computeFingerprint(tokens: Token[], startIndex: number, windowSize: number): string;
/**
 * 计算 Token 数组的哈希值
 *
 * @param tokens Token 数组
 * @returns 哈希值
 */
export declare function computeTokensHash(tokens: Token[]): string;
/**
 * 从窗口创建位置信息
 *
 * @param window 窗口
 * @param defaultFile 默认文件路径（如果窗口没有文件信息）
 * @returns 位置信息
 */
export declare function createLocationFromWindow(window: TokenWindow, defaultFile?: string, tokenFingerprint?: string): FragmentLocation;
//# sourceMappingURL=HashIndex.d.ts.map