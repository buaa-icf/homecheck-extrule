/**
 * Tokenizer - ArkTS 源代码词法分析器
 *
 * 使用 ArkAnalyzer 暴露的 ts.createScanner() 进行词法分析。
 * 该 Scanner 来自 ohos-typescript（OpenHarmony 定制版），原生支持 ArkTS 语法。
 *
 * @module FragmentDetection/Tokenizer
 */
import { ts } from 'arkanalyzer';
import { Token, TokenType } from './Token';
/**
 * Tokenizer 配置选项
 */
export interface TokenizerOptions {
    /** 是否跳过注释（默认 true） */
    skipComments?: boolean;
    /** 是否规范化标识符（默认 false，用于 Type-2 检测时开启） */
    normalizeIdentifiers?: boolean;
    /** 是否规范化字面量（默认 false，用于 Type-2 检测时开启） */
    normalizeLiterals?: boolean;
    /** 是否忽略类型注解（默认 false，开启后去除 : Type、as Type 等类型信息） */
    ignoreTypes?: boolean;
    /** 是否忽略装饰器（默认 false，开启后去除 @Decorator 及其参数） */
    ignoreDecorators?: boolean;
    /** 是否规范化单字符标识符（默认 false，即保留 i, j, x 等循环变量原样） */
    normalizeSingleCharIdentifiers?: boolean;
}
/**
 * 将 TypeScript SyntaxKind 映射为我们的 TokenType
 *
 * @param kind TypeScript 的 SyntaxKind
 * @returns 我们定义的 TokenType
 */
export declare function mapSyntaxKindToTokenType(kind: ts.SyntaxKind): TokenType;
/**
 * 将字符偏移量转换为行号和列号
 *
 * @param text 源代码文本
 * @param offset 字符偏移量
 * @returns { line, column } 行号（1-based）和列号（0-based）
 */
export declare function offsetToLineColumn(text: string, offset: number): {
    line: number;
    column: number;
};
/**
 * Tokenizer 类
 *
 * 将 ArkTS 源代码转换为 Token 序列
 */
export declare class Tokenizer {
    private options;
    private identifierCounter;
    private identifierMap;
    constructor(options?: TokenizerOptions);
    /**
     * 将源代码转换为 Token 序列
     *
     * @param sourceCode 源代码文本
     * @param filePath 文件路径（可选）
     * @returns Token 数组
     */
    tokenize(sourceCode: string, filePath?: string): Token[];
    /**
     * 规范化 Token 值
     */
    private normalizeToken;
    /**
     * 规范化标识符
     *
     * 将变量名、函数名等替换为 ID_0, ID_1, ...
     * 相同的标识符会映射到相同的 ID
     *
     * 注意：单字母标识符不规范化（如 i, j, x），因为它们通常是循环变量
     */
    private normalizeIdentifier;
    /**
     * 规范化字面量
     *
     * - 数字 → NUM
     * - 字符串 → STR
     * - 布尔值 → BOOL
     */
    private normalizeLiteral;
    /**
     * 过滤类型注解 Token
     *
     * 状态机识别类型注解模式：
     * - `: Type` (变量/参数类型标注)
     * - `: Type<T>` (泛型类型)
     * - `as Type` (类型断言)
     *
     * 移除冒号/as 及其后续类型 Token，直到遇到终止符
     */
    private filterTypeAnnotations;
    /**
     * 从当前位置跳过类型注解 Token
     *
     * 处理嵌套泛型 `<>` 和数组 `[]`，
     * 遇到终止符 `=`, `,`, `)`, `{`, `;`, `=>`, `(` 时停止
     */
    private skipTypeAnnotation;
    /**
     * 过滤装饰器 Token
     *
     * 移除 `@` 及其后续标识符，以及可能的参数列表 `(...)`
     */
    private filterDecorators;
    /**
     * 获取当前配置
     */
    getOptions(): TokenizerOptions;
    /**
     * 更新配置
     */
    setOptions(options: Partial<TokenizerOptions>): void;
}
/**
 * 便捷函数：直接 tokenize 源代码
 */
export declare function tokenize(sourceCode: string, filePath?: string, options?: TokenizerOptions): Token[];
/**
 * 便捷函数：tokenize 并规范化（用于 Type-2 检测）
 */
export declare function tokenizeNormalized(sourceCode: string, filePath?: string): Token[];
//# sourceMappingURL=Tokenizer.d.ts.map