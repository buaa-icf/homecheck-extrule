import { BaseMetaData, BaseChecker, Rule, IssueReport, MatcherCallback } from "homecheck";
import { RuleOptionSchema } from "./config/parseRuleOptions";
import { DefectsParams } from "./shared";
/**
 * Issue 上报参数（ruleId / ruleDocPath / severity 由基类自动填充）。
 */
export type IssueParams = Omit<DefectsParams, 'severity' | 'ruleId' | 'ruleDocPath'> & {
    severity?: number;
};
/**
 * 文件级 BaseChecker 通用基类，消除各 Checker 中重复的样板代码。
 *
 * 提供：
 * - 配置解析与惰性初始化（beforeCheck / getOptions）
 * - 统一 Issue 上报入口（reportIssue / getSeverity）
 *
 * 子类只需声明 metaData / optionSchema / defaultOptions，
 * 并实现 registerMatchers() 与具体 check 逻辑。
 */
export declare abstract class BaseRuleChecker<TOptions extends object> implements BaseChecker {
    abstract readonly metaData: BaseMetaData;
    rule: Rule;
    issues: IssueReport[];
    protected abstract readonly optionSchema: RuleOptionSchema<TOptions>;
    protected abstract readonly defaultOptions: TOptions;
    private _resolvedOptions;
    private _optionsInitialized;
    /**
     * 每轮检测开始时重置状态并解析配置。
     */
    beforeCheck(): void;
    /**
     * 获取已解析的配置；未初始化时自动解析（测试场景兜底）。
     */
    protected getOptions(): TOptions;
    /**
     * 统一 severity 解析：支持 rule 覆盖与手动 override。
     */
    protected getSeverity(override?: number): number;
    /**
     * 统一 Issue 上报入口，自动填充 ruleId / ruleDocPath / severity。
     */
    protected reportIssue(params: IssueParams): void;
    abstract registerMatchers(): MatcherCallback[];
    /**
     * 子类通过 registerMatchers 的 callback 实现检测逻辑，
     * 此处提供空默认实现以满足 BaseChecker 接口约束。
     * 子类可自由覆盖签名（如接受 ArkMethod 参数）。
     */
    check: (_target?: any) => void;
}
//# sourceMappingURL=BaseRuleChecker.d.ts.map