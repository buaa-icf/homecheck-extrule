import { Rule } from "homecheck";
type PrimitiveType = "boolean" | "number" | "string";
interface RuleOptionFieldSchema<TValue> {
    type: PrimitiveType;
    aliases?: string[];
    min?: number;
    max?: number;
    allowNaN?: boolean;
    validate?: (value: TValue) => boolean;
    transform?: (value: TValue) => TValue;
}
export type RuleOptionSchema<TOptions extends object> = {
    [K in keyof TOptions]: RuleOptionFieldSchema<TOptions[K]>;
};
export declare function parseRuleOptions<TOptions extends object>(rule: Rule | undefined, schema: RuleOptionSchema<TOptions>, defaults: TOptions): TOptions;
export {};
//# sourceMappingURL=parseRuleOptions.d.ts.map