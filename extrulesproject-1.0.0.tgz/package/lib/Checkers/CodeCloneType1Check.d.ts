import { Stmt } from "arkanalyzer";
import { BaseMetaData } from "homecheck";
import { CodeCloneBaseCheck } from "./CodeCloneBaseCheck";
import { MethodInfo } from "./method-clone";
/**
 * Code Clone Type-1 检测规则
 *
 * Type-1 克隆：完全相同的代码片段（仅空白和注释可以不同）
 *
 * 检测算法：
 * 1. 遍历所有文件中的方法
 * 2. 对每个方法计算语句序列的哈希值（基础规范化）
 * 3. 比较哈希值，找出相同的方法对
 * 4. 上报克隆对
 */
export declare class CodeCloneType1Check extends CodeCloneBaseCheck {
    readonly metaData: BaseMetaData;
    protected getCloneType(): string;
    /**
     * 计算语句序列的哈希值
     * Type-1 克隆要求完全相同，只做基础规范化
     */
    protected computeHash(stmts: Stmt[]): {
        hash: string;
        normalizedContent: string;
    };
    protected getDescription(method: MethodInfo, cloneWith: MethodInfo): string;
}
//# sourceMappingURL=CodeCloneType1Check.d.ts.map