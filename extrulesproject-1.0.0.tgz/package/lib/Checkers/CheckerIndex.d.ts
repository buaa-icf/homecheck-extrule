import { AdviceChecker, BaseChecker } from "homecheck";
type CheckerClass = new () => BaseChecker | AdviceChecker;
export declare const file2CheckRuleMap: Map<string, CheckerClass>;
export declare const project2CheckRuleMap: Map<string, CheckerClass>;
export {};
//# sourceMappingURL=CheckerIndex.d.ts.map