import { Stmt } from "arkanalyzer";
import { BaseMetaData } from "homecheck";
import { CodeCloneBaseCheck } from "./CodeCloneBaseCheck";
import { ClonePair, MethodInfo } from "./method-clone";
/**
 * Code Clone Type-2 检测规则
 *
 * Type-2 克隆：结构相同但标识符（变量名、函数名）不同的代码
 *
 * 检测算法：
 * 1. 遍历所有文件中的方法
 * 2. 对每个方法进行"标识符规范化"（变量名→ID_1, ID_2 等）
 * 3. 计算规范化后的哈希值
 * 4. 比较哈希值，找出结构相同的方法对
 * 5. 上报克隆对
 */
export declare class CodeCloneType2Check extends CodeCloneBaseCheck {
    readonly metaData: BaseMetaData;
    protected getCloneType(): string;
    /**
     * 计算规范化后的哈希值
     * Type-2 需要将标识符替换为占位符
     * 如果配置了 ignoreLiterals: true，还会将字面量替换为占位符
     */
    protected computeHash(stmts: Stmt[]): {
        hash: string;
        normalizedContent: string;
    };
    /**
     * 字面量规范化
     * 将数字、字符串替换为占位符
     *
     * 注意：此功能可能导致误报，默认关闭
     * 只有当配置 ignoreLiterals: true 时才会调用
     *
     * 规范化规则：
     * - 数字（整数、小数、十六进制、科学计数法）→ NUM
     * - 字符串（双引号、单引号）→ STR
     */
    protected getDescription(method: MethodInfo, cloneWith: MethodInfo, pair?: ClonePair): string;
}
//# sourceMappingURL=CodeCloneType2Check.d.ts.map