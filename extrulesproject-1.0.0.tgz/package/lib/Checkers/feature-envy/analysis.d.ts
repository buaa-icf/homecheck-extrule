import { ArkMethod, Stmt } from "arkanalyzer";
export interface FeatureEnvyMetrics {
    atfd: number;
    lda: number;
    cpfd: number;
    dominantProvider: string;
}
export interface FeatureEnvyAnalysisResult {
    metrics: FeatureEnvyMetrics;
    pureMappingAdapter: boolean;
}
export declare function buildFeatureEnvyFieldTypeMap(method: ArkMethod): Map<string, string>;
export declare class FeatureEnvyAnalyzer {
    private readonly selfClass;
    private readonly fieldTypeMap;
    private readonly ignoredClasses;
    constructor(selfClass: string, fieldTypeMap: Map<string, string>, ignoredClasses?: ReadonlySet<string>);
    analyze(stmts: Stmt[]): FeatureEnvyAnalysisResult;
    private collectMetrics;
    private isPureMappingAdapterMethod;
    private findDominantProvider;
    private forEachUniqueInvoke;
    private classifyFieldAccess;
    private getMappedTargetBase;
    private isLocalFieldWrite;
    private collectFreshLocalAliases;
    private isConstructorInvoke;
    private resolveInvokeProvider;
    private resolveProviderFromValue;
    private isForeignProvider;
    private isIgnoredClass;
}
//# sourceMappingURL=analysis.d.ts.map