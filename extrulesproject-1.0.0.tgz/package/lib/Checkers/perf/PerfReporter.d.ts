import { PerfReportShape, StageHandle } from './types';
export declare class PerfReporterImpl {
    enabled: boolean;
    private data;
    private wallStartNs;
    private wallStartIso;
    private exitHookRegistered;
    private exitHandler;
    private peakHeapUsedBytes;
    private peakRssBytes;
    private memSampler;
    private timelinePath;
    private lastTimelineElapsedMs;
    constructor(enabled: boolean, timelinePath?: string);
    /** 采样一次进程内存并更新峰值。 */
    sampleMemory(): void;
    private prepareTimeline;
    private appendTimelineSample;
    private startMemorySampler;
    private registerExitHook;
    start(checker: string, stage: string): StageHandle;
    time<T>(checker: string, stage: string, fn: () => T): T;
    record(checker: string, stage: string, ns: bigint, count?: number): void;
    toJSON(): PerfReportShape;
    flush(filePath?: string): void;
    reset(): void;
    /** 测试 / 长驻进程清理：移除 exit 钩子、停止采样器并清空累计。 */
    dispose(): void;
}
export declare function createPerfReporter(enabled?: boolean, timelinePath?: string | undefined): PerfReporterImpl;
/** 进程单例：检测器代码统一从这里 import。 */
export declare const PerfReporter: PerfReporterImpl;
//# sourceMappingURL=PerfReporter.d.ts.map