export { file2CheckRuleMap, project2CheckRuleMap } from './Checkers/CheckerIndex';
//# sourceMappingURL=index.d.ts.map